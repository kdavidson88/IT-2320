﻿namespace MyFirstJQueryApp.Models
{
    public class HomeModel
    {
        public string Title { get; set; }
    }
}